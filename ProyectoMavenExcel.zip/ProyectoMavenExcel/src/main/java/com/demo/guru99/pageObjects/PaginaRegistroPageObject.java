package com.demo.guru99.pageObjects;

import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.By;

public class PaginaRegistroPageObject extends PageObject {


    By txtNombre = By.name("firstName");
    By txtApellido = By.name("lastName");
    By txtCelular = By.name("phone");
    By txtEmail = By.id("userName");
    By txtNombreUsuario = By.id("email");
    By txtClave = By.name("password");
    By txtConfirmarClave = By.name("confirmPassword");


    public By getTxtNombre() {
        return txtNombre;
    }

    public By getTxtApellido() {
        return txtApellido;
    }

    public By getTxtCelular() {
        return txtCelular;
    }

    public By getTxtEmail() {
        return txtEmail;
    }

    public By getTxtNombreUsuario() {
        return txtNombreUsuario;
    }

    public By getTxtClave() {
        return txtClave;
    }

    public By getTxtConfirmarClave() {
        return txtConfirmarClave;
    }
}
