package com.demo.guru99.steps;

import com.demo.guru99.pageObjects.PaginaRegistroPageObject;
import com.demo.guru99.utils.Excel;
import net.thucydides.core.annotations.Step;

import java.io.IOException;

public class PaginaRegistoStep {

    PaginaRegistroPageObject paginaRegistroPageObject = new PaginaRegistroPageObject();
    Excel excel = new Excel();
    private static final String RUTA = "DatosExcel.xlsx";
    private static final String HOJA = "DatosRegistro";




    @Step
    public void escribirNombre() throws IOException {
        paginaRegistroPageObject.getDriver().findElement(paginaRegistroPageObject.getTxtNombre()).sendKeys(excel.leerDatosExcel(RUTA, HOJA, 1, 0));
    }


    @Step
    public void escribirApellido() throws IOException {
        paginaRegistroPageObject.getDriver().findElement(paginaRegistroPageObject.getTxtApellido()).sendKeys(excel.leerDatosExcel(RUTA, HOJA, 1, 1));

    }

    @Step
    public void escribirCelular() throws IOException {
        paginaRegistroPageObject.getDriver().findElement(paginaRegistroPageObject.getTxtCelular()).sendKeys(excel.leerDatosExcel(RUTA, HOJA, 1, 2));
    }

    @Step
    public void escribirEmail() throws IOException {
        paginaRegistroPageObject.getDriver().findElement(paginaRegistroPageObject.getTxtEmail()).sendKeys(excel.leerDatosExcel(RUTA, HOJA, 1, 3));
    }

    @Step
    public void escribirUsario() throws IOException {
        paginaRegistroPageObject.getDriver().findElement(paginaRegistroPageObject.getTxtNombreUsuario()).sendKeys(excel.leerDatosExcel(RUTA, HOJA, 1, 4));
    }

    @Step
    public void escribirClave() throws IOException {
        paginaRegistroPageObject.getDriver().findElement(paginaRegistroPageObject.getTxtClave()).sendKeys(excel.leerDatosExcel(RUTA, HOJA, 1, 5));
    }


    @Step
    public void escribirConfirmarClave() throws IOException {
        paginaRegistroPageObject.getDriver().findElement(paginaRegistroPageObject.getTxtConfirmarClave()).sendKeys(excel.leerDatosExcel(RUTA, HOJA, 1, 6));
    }


}
