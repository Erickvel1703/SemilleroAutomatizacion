package com.demo.guru99.steps;

import com.demo.guru99.pageObjects.PaginaInicioPageObject;
import com.demo.guru99.pageObjects.PaginaVuelosPageObject;
import com.demo.guru99.utils.EsperaExplicita;
import com.demo.guru99.utils.Excel;
import net.thucydides.core.annotations.Step;

import java.io.IOException;

public class PaginaInicioStep {

PaginaInicioPageObject paginaInicioPageObject = new PaginaInicioPageObject();
EsperaExplicita esperaExplicita = new EsperaExplicita();
PaginaVuelosPageObject paginaVuelosPageObject = new PaginaVuelosPageObject();
Excel excel = new Excel();

    public PaginaInicioStep() throws IOException {
    }


    @Step
    public void abrirNavegador () throws IOException {
        paginaInicioPageObject.openUrl(excel.leerDatosExcel("DatosExcel.xlsx","DatosVuelo",1,0));
    }



    @Step
    public void clickVuelos (){
        paginaInicioPageObject.getDriver().findElement(paginaInicioPageObject.getBtnVuelos()).click();
        esperaExplicita.esperaExplicitaClick(paginaInicioPageObject.getDriver(),paginaVuelosPageObject.getRdoIda());
    }




   @Step
   public void clickRegistrar(){
        paginaInicioPageObject.getDriver().findElement(paginaInicioPageObject.getBtnRegistro()).click();
   }
}
