package com.demo.guru99.stepDefinitions;

import com.demo.guru99.steps.PaginaInicioStep;
import com.demo.guru99.steps.PaginaVuelosStep;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;

import java.io.IOException;


public class VueloStepDefinition {

    @Steps
    PaginaInicioStep paginaInicioStep;

    @Steps
    PaginaVuelosStep paginaVuelosStep;


    @Given("el usuario se encuentre en la pagina web")
    public void el_usuario_se_encuentre_en_la_pagina_web() throws IOException {
        paginaInicioStep.abrirNavegador();


    }

    @When("el usuario cambie la informacion del vuelo")
    public void el_usuario_cambie_la_informacion_del_vuelo() throws IOException {
        paginaInicioStep.clickVuelos();
        paginaVuelosStep.clicIda();
        paginaVuelosStep.seleccionarPasajeros();
        paginaVuelosStep.seleccionarCiudadOrigen();
        paginaVuelosStep.seleccionarMesIda();
        paginaVuelosStep.seleccionarDiaIda();
        paginaVuelosStep.seleccionarCiudadDestino();
        paginaVuelosStep.seleccionarMesVuelta();
        paginaVuelosStep.seleccionarDiaVuelta();
        paginaVuelosStep.seleccionarClase();
        paginaVuelosStep.seleccionarAerolinea();
        paginaVuelosStep.clickContinuar();



    }

    @Then("el visualizara un mensaje de que no hay asientos disponibles")
    public void el_visualizara_un_mensaje_de_que_no_hay_asientos_disponibles() {

        paginaVuelosStep.validarMensajeVuelos();
    }

}
