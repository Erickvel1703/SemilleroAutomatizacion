package com.demo.guru99.stepDefinitions;


import com.demo.guru99.steps.PaginaInicioStep;
import com.demo.guru99.steps.PaginaRegistoStep;
import com.demo.guru99.steps.PaginaVuelosStep;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;

import java.io.IOException;

public class RegistroStepDefinition {

@Steps
    PaginaInicioStep paginaInicioStep;

@Steps
    PaginaRegistoStep paginaRegistoStep;



    @Given("que el usuario se encuentre en el modulo de registro")
    public void queElUsuarioSeEncuentreEnElModuloDeRegistro() {
       paginaInicioStep.clickRegistrar();


    }
    @When("el usuario diligencia el formulario de registro")
    public void elUsuarioDiligenciaElFormularioDeRegistro() throws IOException {
        paginaRegistoStep.escribirNombre();
        paginaRegistoStep.escribirApellido();
        paginaRegistoStep.escribirCelular();
        paginaRegistoStep.escribirEmail();
        paginaRegistoStep.escribirUsario();
        paginaRegistoStep.escribirClave();
        paginaRegistoStep.escribirConfirmarClave();






    }
    @Then("el usuario visualizara el mensaje de registro exitoso")
    public void elUsuarioVisualizaraElMensajeDeRegistroExitoso() {

    }



}
