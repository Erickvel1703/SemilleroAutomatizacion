package com.demo.guru99.pageObjects;

import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.By;

public class PaginaUsuarioPageObject extends PageObject {

    By msjLoginExitoso = By.xpath("//h3[text()='Login Successfully']");
    By btnVuelos = By.xpath("//a[text()='Flights']");


    public By getMsjLoginExitoso() {
        return msjLoginExitoso;
    }

    public By getBtnVuelos() {
        return btnVuelos;
    }
}
