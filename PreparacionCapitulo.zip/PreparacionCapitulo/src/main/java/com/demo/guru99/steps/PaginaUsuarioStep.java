package com.demo.guru99.steps;

import com.demo.guru99.pageObjects.PaginaUsuarioPageObject;
import net.thucydides.core.annotations.Step;
import org.hamcrest.Matchers;
import org.junit.Assert;

public class PaginaUsuarioStep {


PaginaUsuarioPageObject paginaUsuarioPageObject = new PaginaUsuarioPageObject();



    @Step
    public void validarMensajeLogin (){
        Assert.assertThat(paginaUsuarioPageObject.getDriver().findElement(paginaUsuarioPageObject.getMsjLoginExitoso()).isDisplayed(), Matchers.is(true));
    }


    @Step
    public void clicVuelos (){
        paginaUsuarioPageObject.getDriver().findElement(paginaUsuarioPageObject.getBtnVuelos()).click();
    }

}
