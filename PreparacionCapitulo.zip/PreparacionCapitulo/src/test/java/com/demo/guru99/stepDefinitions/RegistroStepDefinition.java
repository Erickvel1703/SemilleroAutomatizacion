package com.demo.guru99.stepDefinitions;

import com.demo.guru99.steps.PaginaInicioStep;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class RegistroStepDefinition {





    @When("el diligencia el formulario de registro de la pagina")
    public void elDiligenciaElFormularioDeRegistroDeLaPagina() {

    }
    @Then("el usuario visualizara un mensaje de registro exitoso")
    public void elUsuarioVisualizaraUnMensajeDeRegistroExitoso() {

    }




}
