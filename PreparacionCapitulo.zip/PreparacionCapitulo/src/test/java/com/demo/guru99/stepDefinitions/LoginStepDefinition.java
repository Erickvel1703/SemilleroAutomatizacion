package com.demo.guru99.stepDefinitions;


import com.demo.guru99.steps.PaginaInicioStep;
import com.demo.guru99.steps.PaginaUsuarioStep;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;

import java.util.List;
import java.util.Map;


public class LoginStepDefinition {


    @Steps
    PaginaInicioStep paginaInicioStep;

    @Steps
    PaginaUsuarioStep paginaUsuarioStep;


    @Given("que el usuario se encuentre en la pagina web")
    public void queElUsuarioSeEncuentreEnLaPaginaWeb() {
        paginaInicioStep.abrirNavegador();


    }

    @When("ingresa el usuario con la clave")
    public void ingresaElUsuarioConLaClave(DataTable dataTable) {
        List<Map<String, String>> rows =dataTable.asMaps(String.class, String.class);
        paginaInicioStep.escribirUsuario(rows.get(0).get("Usuario"));
        paginaInicioStep.escribirClave(rows.get(0).get("Clave"));
        paginaInicioStep.clickIngresar();




    }

    @Then("el usuario visualizara un mensaje de login exitoso")
    public void elUsuarioVisualizaraUnMensajeDeLoginExitoso() {
        paginaUsuarioStep.validarMensajeLogin();


    }


    @When("el usuario ingrese las credenciales incorrectas")
    public void elUsuarioIngreseLasCredencialesIncorrectas(DataTable dataTable) {
        List<Map<String, String>> row =dataTable.asMaps(String.class, String.class);
        paginaInicioStep.escribirUsuario(row.get(0).get("Usuarios"));
        paginaInicioStep.escribirClave(row.get(0).get("Claves"));
        paginaInicioStep.clickIngresar();



    }
    @Then("el usuario visualizara un mensaje credenciales incorrectas")
    public void elUsuarioVisualizaraUnMensajeCredencialesIncorrectas() {
    paginaInicioStep.ValidarMsjLoginFallido();



    }





}
