package com.demo.guru99.stepDefinitions;

import com.demo.guru99.steps.PaginaInicioStep;
import com.demo.guru99.steps.PaginaUsuarioStep;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;

public class VueloStepDefinition {

    @Steps
    PaginaUsuarioStep paginaUsuarioStep;





    @Given("el usuario se encuentre en la opcion de vuelos")
    public void elUsuarioSeEncuentreEnLaOpcionDeVuelos() {
        paginaUsuarioStep.clicVuelos();




    }

    @When("el usuario cambie la informacion del vuelo")
    public void elUsuarioCambieLaInformacionDelVuelo() {

    }

    @When("el de clic en continuar")
    public void elDeClicEnContinuar() {

    }

    @Then("el visualizara un mensaje de que no hay asientos disponibles")
    public void elVisualizaraUnMensajeDeQueNoHayAsientosDisponibles() {

    }

}
