package com.demo.guru99.stepDefinitions;


import com.demo.guru99.steps.PaginaInicioStep;
import com.demo.guru99.steps.PaginaUsuarioStep;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;

import java.util.List;
import java.util.Map;

public class LoginStepDefinition {


    @Steps
    PaginaInicioStep paginaInicioStep;

    @Steps
    PaginaUsuarioStep paginaUsuarioStep;


    @Given("que el usuario se encuentra en la pagina web")
    public void queElUsuarioSeEncuentraEnLaPaginaWeb() {
        paginaInicioStep.abrirNavegador();


    }

    @When("ingresa el usuario con la clave")
    public void ingresaElUsuarioConLaClave(DataTable dataTable) {
        List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);
        paginaInicioStep.escribirUsuario(rows.get(0).get("Usuario"));
        paginaInicioStep.escribirClave(rows.get(0).get("Clave"));
        paginaInicioStep.clickIngresar();



    }

    @Then("el usuario visualizara un mensaje de login exitoso")
    public void elUsuarioVisualizaraUnMensajeDeLoginExitoso() {
        paginaUsuarioStep.validarMensajeLoginExitoso();


    }



    @When("el usuario ingrese las credenciales incorrectas")
    public void el_usuario_ingrese_las_credenciales_incorrectas(DataTable dataTable) {
        List<Map<String, String>> row = dataTable.asMaps(String.class, String.class);
        paginaInicioStep.escribirUsuario(row.get(0).get("Usuario"));
        paginaInicioStep.escribirClave(row.get(0).get("Clave"));
        paginaInicioStep.clickIngresar();




    }
    @Then("el usuario visualizara un mensaje de credenciales incorrectas")
    public void el_usuario_visualizara_un_mensaje_de_credenciales_incorrectas() {
    paginaInicioStep.validarMensajeLoginFaliido();

    }



}


