package com.demo.guru99.steps;

import com.demo.guru99.pageObjects.PaginaInicioPageObject;
import net.thucydides.core.annotations.Step;
import org.hamcrest.Matchers;
import org.junit.Assert;

public class PaginaInicioStep {


    PaginaInicioPageObject paginaInicioPageObject = new PaginaInicioPageObject();


    @Step
    public void abrirNavegador() {
        paginaInicioPageObject.open();

    }

    @Step
    public void escribirUsuario(String usuario) {
        paginaInicioPageObject.getDriver().findElement(paginaInicioPageObject.getTxtUsurio()).sendKeys(usuario);

    }


    @Step
    public void escribirClave(String clave) {
        paginaInicioPageObject.getDriver().findElement(paginaInicioPageObject.getTxtClave()).sendKeys(clave);

    }


    @Step
    public void clickIngresar(){
        paginaInicioPageObject.getDriver().findElement(paginaInicioPageObject.getBtnIngresar()).click();
    }


    @Step
    public void validarMensajeLoginFaliido(){
        Assert.assertThat(paginaInicioPageObject.getDriver().findElement(paginaInicioPageObject.getMsjLoginFallido()).isDisplayed(), Matchers.is(true));
    }



}
