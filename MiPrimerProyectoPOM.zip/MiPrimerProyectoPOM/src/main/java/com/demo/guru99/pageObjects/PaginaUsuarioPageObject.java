package com.demo.guru99.pageObjects;

import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.By;

public class PaginaUsuarioPageObject extends PageObject {

    By txtLoginExitoso = By.xpath("//h3[text()='Login Successfully']");
    By btnVuelos = By.xpath("//a[text()='Flights']");


    public By getTxtLoginExitoso() {
        return txtLoginExitoso;
    }

    public By getBtnVuelos() {
        return btnVuelos;
    }
}
