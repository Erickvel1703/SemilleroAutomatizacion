package com.demo.guru99.steps;

import com.demo.guru99.pageObjects.PaginaInicioPageObject;
import com.demo.guru99.utils.Excel;
import net.thucydides.core.annotations.Step;
import org.hamcrest.Matchers;
import org.junit.Assert;

import java.io.IOException;

public class PaginaInicioStep {


    PaginaInicioPageObject paginaInicioPageObject = new PaginaInicioPageObject();
    Excel excel = new Excel();


    @Step
    public void abrirNavegador() throws IOException {
        paginaInicioPageObject.openUrl(excel.leerDatosExcel("DatosProyectoExcel.xlsx","DatosVuelo",1,0));

    }


    @Step
    public void clickVuelos (){
        paginaInicioPageObject.getDriver().findElement(paginaInicioPageObject.getBtnVuelos()).click();
    }


    @Step
    public void clickRegistrar(){
        paginaInicioPageObject.getDriver().findElement(paginaInicioPageObject.getBtnRegistro()).click();
    }



}
