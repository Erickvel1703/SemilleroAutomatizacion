package com.demo.guru99.pageObjects;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;
import org.openqa.selenium.By;


public class PaginaInicioPageObject extends PageObject {


By btnVuelos = By.xpath("//a[text()='Flights']");
By btnRegistro = By.xpath("//a[text()='REGISTER']");

    public By getBtnVuelos() {
        return btnVuelos;
    }

    public By getBtnRegistro() {
        return btnRegistro;
    }
}
