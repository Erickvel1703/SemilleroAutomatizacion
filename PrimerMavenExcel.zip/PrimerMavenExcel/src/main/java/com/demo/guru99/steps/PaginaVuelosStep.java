package com.demo.guru99.steps;

import com.demo.guru99.pageObjects.PaginaVuelosPageObject;
import com.demo.guru99.utils.Excel;
import com.demo.guru99.utils.Lista;
import net.thucydides.core.annotations.Step;
import org.hamcrest.Matchers;
import org.junit.Assert;

import java.io.IOException;

public class PaginaVuelosStep {

    PaginaVuelosPageObject paginaVuelosPageObject = new PaginaVuelosPageObject();
    Excel excel = new Excel();
    Lista lista = new Lista();

    public PaginaVuelosStep() throws IOException {
    }


    @Step
    public void clicIda (){

        paginaVuelosPageObject.getDriver().findElement(paginaVuelosPageObject.getRdoIda()).click();

    }


    @Step
    public void clicListaPasajeros () throws IOException {
        String valor= excel.leerDatosExcel("DatosProyectoExcel.xlsx","DatosVuelo",1,1);
        lista.seleccionarTextoVisible(paginaVuelosPageObject.getDriver(),paginaVuelosPageObject.getLstPasajeros(),valor);

    }

    @Step
    public void clickCiudadOrigen() throws IOException {
        String valor= excel.leerDatosExcel("DatosProyectoExcel.xlsx","DatosVuelo",1,2);
        lista.seleccionarTextoVisible(paginaVuelosPageObject.getDriver(),paginaVuelosPageObject.getLstOrigen(),valor);

    }

    @Step
    public void clickMesIda() throws IOException {

        String valor= excel.leerDatosExcel("DatosProyectoExcel.xlsx","DatosVuelo",1,3);
        lista.seleccionarTextoVisible(paginaVuelosPageObject.getDriver(),paginaVuelosPageObject.getLstMesIda(),valor);

    }


    @Step
    public void clickDiaIda() throws IOException {

        String valor= excel.leerDatosExcel("DatosProyectoExcel.xlsx","DatosVuelo",1,4);
        lista.seleccionarTextoVisible(paginaVuelosPageObject.getDriver(),paginaVuelosPageObject.getLstDiaIda(),valor);

    }

    @Step
    public void seleccionarCiudadDestino() throws IOException {
        String valor= excel.leerDatosExcel("DatosProyectoExcel.xlsx","DatosVuelo",1,5);
        lista.seleccionarTextoVisible(paginaVuelosPageObject.getDriver(),paginaVuelosPageObject.getLstDestino(),valor);

    }


    @Step
    public void seleccionarMesVuelta() throws IOException {

        String valor= excel.leerDatosExcel("DatosProyectoExcel.xlsx","DatosVuelo",1,6);
        lista.seleccionarTextoVisible(paginaVuelosPageObject.getDriver(),paginaVuelosPageObject.getLstMesRegreso(),valor);

    }

    @Step
    public void seleccionarDiaVuelta() throws IOException {
        String valor= excel.leerDatosExcel("DatosProyectoExcel.xlsx","DatosVuelo",1,7);
        lista.seleccionarTextoVisible(paginaVuelosPageObject.getDriver(),paginaVuelosPageObject.getLstDiaRegreso(),valor);

    }

    @Step
    public void seleccionarClase(){
        paginaVuelosPageObject.getDriver().findElement(paginaVuelosPageObject.getRdoClase()).click();

    }

    @Step
    public void seleccionarAerolinea() throws IOException {
        String valor= excel.leerDatosExcel("DatosProyectoExcel.xlsx","DatosVuelo",1,8);
        lista.seleccionarTextoVisible(paginaVuelosPageObject.getDriver(),paginaVuelosPageObject.getLstAerolinea(),valor);


    }

    @Step
    public void clickContinuar(){
        paginaVuelosPageObject.getDriver().findElement(paginaVuelosPageObject.getBtnContinuar()).click();

    }


    @Step
    public void validarMensajeVuelos(){
        Assert.assertThat(paginaVuelosPageObject.getDriver().findElement(paginaVuelosPageObject.getMsjVuelos()).isDisplayed(), Matchers.is(true));

    }


}
