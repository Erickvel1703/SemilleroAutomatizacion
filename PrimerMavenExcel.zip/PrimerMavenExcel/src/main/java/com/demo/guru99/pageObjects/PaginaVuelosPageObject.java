package com.demo.guru99.pageObjects;

import com.demo.guru99.utils.Excel;
import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.By;

import java.io.IOException;

public class PaginaVuelosPageObject extends PageObject {

    Excel excel = new Excel();



    By rdoIda = By.xpath("//input[@value='oneway']");
    By lstPasajeros = By.xpath("//select[@name='passCount']");
    By lstOrigen = By.xpath("//select[@name='fromPort']");
    By lstMesIda = By.xpath("//select[@name='fromMonth']");
    By lstDiaIda = By.xpath("//select[@name='fromDay']");
    By lstDestino = By.xpath("//select[@name='toPort']");
    By lstMesRegreso = By.xpath("//select[@name='toMonth']");
    By lstDiaRegreso = By.xpath("//select[@name='toDay']");
    By rdoClase = By.xpath("//input[@value='First']");
    By lstAerolinea = By.xpath("//select[@name='airline']");
    By btnContinuar = By.name("findFlights");
    By msjVuelos = By.xpath("//font[contains(text(),'"+excel.leerDatosExcel("DatosProyectoExcel.xlsx","DatosVuelo",1,9)+"')]");

    public PaginaVuelosPageObject() throws IOException {
    }


    public By getRdoIda() {
        return rdoIda;
    }


    public By getLstPasajeros() {
        return lstPasajeros;
    }

    public By getLstOrigen() {
        return lstOrigen;
    }

    public By getLstMesIda() {
        return lstMesIda;
    }

    public By getLstDiaIda() {
        return lstDiaIda;
    }

    public By getLstDestino() {
        return lstDestino;
    }

    public By getLstMesRegreso() {
        return lstMesRegreso;
    }

    public By getLstDiaRegreso() {
        return lstDiaRegreso;
    }

    public By getRdoClase() {
        return rdoClase;
    }

    public By getLstAerolinea() {
        return lstAerolinea;
    }

    public By getBtnContinuar() {
        return btnContinuar;
    }

    public By getMsjVuelos() {
        return msjVuelos;
    }
}
