package com.demo.guru99.stepDefinitions;


import com.demo.guru99.steps.PaginaInicioStep;
import com.demo.guru99.steps.PaginaRegistroStep;
import io.cucumber.java.en.*;
import net.thucydides.core.annotations.Steps;

import java.io.IOException;


public class RegistroStepDefinition {

    @Steps
    PaginaInicioStep paginaInicioStep;

    @Steps
    PaginaRegistroStep paginaRegistroStep;




    @Given("que el usuario se encuentre en el modulo de registro")
    public void queElUsuarioSeEncuentreEnElModuloDeRegistro() {
        paginaInicioStep.clickRegistrar();



    }
    @When("el usuario diligencia el formulario de registro")
    public void elUsuarioDiligenciaElFormularioDeRegistro() throws IOException {

        paginaRegistroStep.escribirNombre();
        paginaRegistroStep.escribirApellido();
        paginaRegistroStep.escribirCelular();
        paginaRegistroStep.escribirCorreo();
        paginaRegistroStep.escribirUsuario();
        paginaRegistroStep.escribirClave();
        paginaRegistroStep.escribirConfirmarClave();


    }
    @Then("el usuario visualizara el mensaje de registro exitoso")
    public void elUsuarioVisualizaraElMensajeDeRegistroExitoso() {

    }




}
