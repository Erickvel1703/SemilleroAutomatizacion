package com.demo.guru99.stepDefinitions;


import com.demo.guru99.steps.PaginaInicioStep;
import com.demo.guru99.steps.PaginaVuelosStep;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;

import java.io.IOException;

public class VueloStepDefinition {


    @Steps
    PaginaInicioStep paginaInicioStep;

    @Steps
    PaginaVuelosStep paginaVuelosStep;


    @Given("el usuario se encuentre en la pagina web")
    public void elUsuarioSeEncuentreEnLaPaginaWeb() throws IOException {
        paginaInicioStep.abrirNavegador();
        paginaInicioStep.clickVuelos();

    }
    @When("el usuario cambie la informacion del vuelo")
    public void elUsuarioCambieLaInformacionDelVuelo() throws IOException {
        paginaVuelosStep.clicIda();
        paginaVuelosStep.clicListaPasajeros();
        paginaVuelosStep.clickCiudadOrigen();
        paginaVuelosStep.clickMesIda();
        paginaVuelosStep.clickDiaIda();
        paginaVuelosStep.seleccionarCiudadDestino();
        paginaVuelosStep.seleccionarMesVuelta();
        paginaVuelosStep.seleccionarDiaVuelta();
        paginaVuelosStep.seleccionarClase();
        paginaVuelosStep.seleccionarAerolinea();
        paginaVuelosStep.clickContinuar();


    }
    @Then("el visualizara un mensaje de que no hay asientos disponibles")
    public void elVisualizaraUnMensajeDeQueNoHayAsientosDisponibles() {
        paginaVuelosStep.validarMensajeVuelos();

    }




}
